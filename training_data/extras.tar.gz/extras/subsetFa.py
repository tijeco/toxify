from itertools import groupby
import sys


def fasta_iter(fasta_name):
    fh = open(fasta_name)
    faiter = (x[1] for x in groupby(fh, lambda line: line[0] == ">"))
    for header in faiter:
        headerStr = header.__next__()[1:].strip().split()[0]#Entire line, add .split[0] for just first column
        seq = "".join(s.strip() for s in faiter.__next__())
        yield (headerStr, seq)
headerDict = {}
with open(sys.argv[1]) as f:
    for line in f:
        headerDict[line.strip()] = True

for ff in fasta_iter(sys.argv[2]):
    headerStr, seq = ff
    if headerStr in headerDict:
        print(">"+headerStr)
        print(seq)
